import os
import time
import json
import uuid
import threading
import random
import pandas as pd
import io
from flask import Flask, request, jsonify, send_from_directory, send_file, Response
from flask_cors import CORS
from dotenv import load_dotenv
from scraper import scrape_linkedin_profile
from extractor import extract_profile_data
from website_scraper import scrape_generic_website, scrape_website_rich
from website_extractor import extract_website_data
from google_searcher import search_google
from logger import log, log_manager
from leads_store import save_new_leads, get_all_leads, get_lead_count, clear_all_leads, delete_lead

# In-memory store for bulk jobs (use a proper DB/queue for production)
bulk_jobs = {}

# Load environment variables
load_dotenv()

app = Flask(__name__, static_folder='public')
CORS(app)

@app.route('/')
def index():
    return send_from_directory('public', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('public', path)

@app.route('/api/health')
def health_check():
    import shutil
    info = {
        "status": "ok",
        "groq_key_set": bool(os.getenv("GROQ_API_KEY")),
        "li_at_set": bool(os.getenv("LI_AT")),
        "playwright_browsers_path": os.getenv("PLAYWRIGHT_BROWSERS_PATH", "(default)"),
    }
    # Check if chromium binary exists
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
            browser.close()
            info["chromium"] = "ok"
    except Exception as e:
        info["chromium"] = f"FAILED: {str(e)}"
    return jsonify(info)

@app.route('/api/logs')
def stream_logs():
    def generate():
        q = log_manager.subscribe()
        try:
            while True:
                msg = q.get()
                yield f"data: {msg}\n\n"
        finally:
            log_manager.unsubscribe(q)
            
    return Response(generate(), mimetype='text/event-stream')

@app.route('/api/scrape', methods=['POST'])
def scrape():
    data = request.json
    url = data.get('url')
    
    if not url:
        return jsonify({"error": "URL is required"}), 400
        
    print(f"Received scrape request for: {url}")
    
    try:
        # Check for LI_AT cookie(s)
        li_at_raw = os.getenv("LI_AT")
        if not li_at_raw:
            print("WARNING: LI_AT cookie missing")
            return jsonify({"error": "Configuration error: LinkedIn session cookie (LI_AT) missing from server environment."}), 500
            
        # Support multiple cookies separated by comma
        cookies = [c.strip() for c in li_at_raw.split(',') if c.strip()]
        selected_cookie = random.choice(cookies)
            
        # Step 1: Scrape
        result = scrape_linkedin_profile(url, headless=True, li_at_cookie=selected_cookie, check_activity=True)
        
        if not result:
            return jsonify({"error": "Failed to scrape profile. Ensure the URL is correct and the server has access."}), 500
            
        # Step 2: Extract
        profile_data = extract_profile_data(result['visible_text'])
        
        if not profile_data:
             return jsonify({"error": "Failed to extract data from the scraped text."}), 500
             
        # Merge activity data
        profile_data['is_active'] = result['is_active']
        profile_data['latest_activity_date'] = result['latest_activity_date']
             
        return jsonify(profile_data)
        
    except Exception as e:
        print(f"Server error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/scrape-website', methods=['POST'])
def scrape_website():
    data = request.json
    url = data.get('url')
    
    if not url:
        return jsonify({"error": "URL is required"}), 400
        
    print(f"Received website scrape request for: {url}")
    
    try:
        scraped = scrape_website_rich(url, headless=True)
        if not scraped:
            return jsonify({"error": "Failed to scrape website."}), 500
            
        # Extract data using AI with structural signals + screenshot for accuracy
        site_data = extract_website_data(
            scraped.get('visible_text', ''),
            structural_signals=scraped.get('structural_signals'),
            screenshot_b64=scraped.get('screenshot_b64')
        )
        
        if not site_data:
             return jsonify({"error": "Failed to extract insights from website text."}), 500

        return jsonify(site_data)
        
    except Exception as e:
         import traceback
         tb = traceback.format_exc()
         print(tb)
         return jsonify({"error": f"Server Error: {str(e)}", "traceback": tb}), 500

def run_bulk_analysis(job_id, df, li_at_raw, extract_only=False):
    results = []
    total = len(df)
    
    # Split cookies for rotation
    cookies = [c.strip() for c in li_at_raw.split(',') if c.strip()]
    if not cookies:
        bulk_jobs[job_id]['status'] = 'error'
        bulk_jobs[job_id]['error'] = 'No valid LinkedIn cookies found.'
        return
    
    # Try to find a column with "linkedin" in the name
    li_col = next((c for c in df.columns if 'linkedin' in c.lower()), None)
    
    if not li_col:
        bulk_jobs[job_id]['status'] = 'error'
        bulk_jobs[job_id]['error'] = 'Could not find a LinkedIn URL column.'
        return

    log(f"Starting bulk analysis for job {job_id[:8]} ({total} rows)")
    for index, row in df.iterrows():
        if bulk_jobs[job_id].get('stop_requested'):
            log(f"Stop requested for job {job_id[:8]}. Halting processing.")
            break
            
        url = str(row[li_col]).strip()
        progress = int(((index) / total) * 100)
        bulk_jobs[job_id]['progress'] = progress
        
        log(f"Processing row {index + 1}/{total}: {url}")
        if not url or 'linkedin.com' not in url:
            results.append({**row.to_dict(), "error": "Invalid URL"})
            continue
            
        try:
            # Rotate cookie
            selected_cookie = cookies[index % len(cookies)]
            
            # Random delay to mimic human behavior
            delay = random.uniform(10, 25)
            log(f"Waiting {delay:.1f}s before scraping {url}...")
            time.sleep(delay)

            # Stage 1: LinkedIn to get Website + Activity
            log(f"Scraping LinkedIn for {url} (Activity Check: ON) [Cookie {index % len(cookies) + 1}/{len(cookies)}]")
            scrape_result = scrape_linkedin_profile(url, headless=True, li_at_cookie=selected_cookie, check_activity=True)
            
            p_data = {}
            extract_only_website_found = None

            if not scrape_result:
                # If scraping failed (Block/Authwall), try Ultimate Fallback if we have Company Name input
                company_input = row.get('company') or row.get('Company') or row.get('company_name') or row.get('Company Name')
                if company_input and isinstance(company_input, str):
                    print(f"LinkedIn blocked or failed. Attempting Google Search for provided company: {company_input}")
                    found_url = search_google(f"{company_input} official site")
                    if found_url:
                        # Success via fallback!
                        extract_only_website_found = found_url
                        
                        # If extract_only mode, we are done
                        if extract_only:
                             results.append({**row.to_dict(), "website_url": found_url, "enrichment_source": "Google Search (Fallback)"})
                             continue
                        
                        # Otherwise, we have the URL, proceed to Stage 2 (Website Analysis)
                        # We simulate p_data with what we found
                        p_data = {'website_url': found_url, 'company_name': company_input, 'enrichment_source': "Google Search (Fallback)"}
                    else:
                        results.append({**row.to_dict(), "error": "Profile scrape failed & Google Search failed"})
                        continue
                else:
                    results.append({**row.to_dict(), "error": "Profile scrape failed (Authwall/Block)"})
                    continue
            else:
                # LinkedIn scrape succeeded — extract profile data
                p_data = extract_profile_data(scrape_result['visible_text'])
                if p_data:
                    p_data['is_active'] = scrape_result['is_active']
                    p_data['latest_activity_date'] = scrape_result['latest_activity_date']
            
            web_url = p_data.get('website_url') if p_data else None
            
            if web_url:
                log(f"Website found on LinkedIn: {web_url}")
            else:
                log("No website found on LinkedIn profile.")
                # GOOGLE SEARCH FALLBACK
                company = row.get('company') or row.get('Company') or p_data.get('company_name')
                if company:
                    log(f"Entering Fallback: Searching Google for '{company}' official site...")
                    found_url = search_google(f"{company} official site")
                    if found_url:
                        log(f"Google Fallback SUCCESS: Found {found_url}")
                        web_url = found_url
                        if not p_data: p_data = {}
                        p_data['website_url'] = found_url
                        p_data['enrichment_source'] = "Google Search"
                    else:
                        log(f"Google Fallback FAILED for '{company}'.")
                        results.append({**row.to_dict(), **(p_data or {}), "error": "No website found (Google search failed)"})
                        continue
                else:
                    log("No company name available for Google fallback.")
                    results.append({**row.to_dict(), **(p_data or {}), "error": "No website found (and no company name extracted)"})
                    continue

            if extract_only:
                results.append({**row.to_dict(), "website_url": web_url, "enrichment_source": p_data.get('enrichment_source', 'LinkedIn')})
                continue
                
            # Stage 2: Analyze Website
            scraped = scrape_website_rich(web_url, headless=True)
            if not scraped:
                results.append({**row.to_dict(), "website_url": web_url, "error": "Website scrape failed", "enrichment_source": p_data.get('enrichment_source', 'LinkedIn')})
                continue
                
            site_data = extract_website_data(
                scraped.get('visible_text', ''),
                structural_signals=scraped.get('structural_signals'),
                screenshot_b64=scraped.get('screenshot_b64')
            )
            if not site_data:
                results.append({**row.to_dict(), "website_url": web_url, "error": "AI analysis failed", "enrichment_source": p_data.get('enrichment_source', 'LinkedIn')})
                continue
                
            # Combine
            results.append({**row.to_dict(), **p_data, **site_data, "website_url": web_url})
            
        except Exception as e:
            print(f"Error processing row {index}: {e}")
            results.append({**row.to_dict(), "error": str(e)})

    # Finalize
    output_df = pd.DataFrame(results)
    bulk_jobs[job_id]['results_df'] = output_df
    bulk_jobs[job_id]['progress'] = 100
    bulk_jobs[job_id]['status'] = 'completed'

def run_bulk_website_job(job_id, df):
    try:
        results = []
        total = len(df)
        
        # Priority: exact "website" column first, then "url", then fallback
        url_col = None
        for c in df.columns:
            if c.strip().lower() == 'website':
                url_col = c
                break
        if not url_col:
            for c in df.columns:
                if c.strip().lower() == 'url':
                    url_col = c
                    break
        if not url_col:
            url_col = next((c for c in df.columns if 'website' in c.lower() or 'url' in c.lower() and 'linkedin' not in c.lower()), None)
        if not url_col:
            # Fallback to first column if no obvious name matches
            url_col = df.columns[0]
        
        log(f"Bulk website job {job_id[:8]}: Using column '{url_col}' for URLs ({total} rows)")
        log(f"Available columns: {list(df.columns)}")

        # Output file path for incremental saving
        output_path = os.path.join(os.path.dirname(__file__) or '.', f'bulk_website_{job_id[:8]}.xlsx')
        
        for row_num, (index, row) in enumerate(df.iterrows()):
            if bulk_jobs[job_id].get('stop_requested'):
                log(f"[Website Bulk] Stop requested for job {job_id[:8]}. Halting.")
                break
                
            url = str(row[url_col]).strip()
            progress = int(((row_num + 1) / total) * 100)
            bulk_jobs[job_id]['progress'] = progress
            
            log(f"[Website Bulk] Processing row {row_num + 1}/{total} ({progress}%): {url}")

            # skip empty
            if not url or len(url) < 4 or url.lower() == 'nan':
                results.append({**row.to_dict(), "error": "Invalid URL"})
                _save_partial_results(results, output_path, job_id)
                continue
                
            try:
                # Stage 1: Analyze Website directly
                if not url.startswith('http'):
                    url = 'https://' + url
                    
                scraped = scrape_website_rich(url, headless=True)
                if not scraped:
                    results.append({**row.to_dict(), "analyzed_url": url, "error": "Website scrape failed"})
                    _save_partial_results(results, output_path, job_id)
                    continue
                    
                site_data = extract_website_data(
                    scraped.get('visible_text', ''),
                    structural_signals=scraped.get('structural_signals'),
                    screenshot_b64=scraped.get('screenshot_b64')
                )
                if not site_data:
                    results.append({**row.to_dict(), "analyzed_url": url, "error": "AI analysis failed"})
                    _save_partial_results(results, output_path, job_id)
                    continue
                    
                # Combine
                results.append({**row.to_dict(), **site_data, "analyzed_url": url})
                log(f"[Website Bulk] Row {row_num + 1}/{total} analyzed successfully.")
                
            except Exception as e:
                print(f"Error processing row {row_num}: {e}")
                results.append({**row.to_dict(), "error": str(e)})

            # Save after every row (success or failure)
            _save_partial_results(results, output_path, job_id)
            
            # Rate-limit cooldown: Cerebras allows 30 RPM, but add small buffer
            if row_num < total - 1 and not bulk_jobs[job_id].get('stop_requested'):
                time.sleep(3)

        # Finalize
        output_df = pd.DataFrame(results)
        bulk_jobs[job_id]['results_df'] = output_df
        bulk_jobs[job_id]['progress'] = 100
        bulk_jobs[job_id]['status'] = 'completed'
        log(f"[Website Bulk] Job {job_id[:8]} completed. {total} rows processed.")

    except Exception as e:
        import traceback
        traceback.print_exc()
        log(f"[Website Bulk] FATAL ERROR in job {job_id[:8]}: {e}")
        bulk_jobs[job_id]['status'] = 'error'
        bulk_jobs[job_id]['error'] = str(e)


def _save_partial_results(results, output_path, job_id):
    """Save current results to disk so partial data is always available."""
    try:
        partial_df = pd.DataFrame(results)
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            partial_df.to_excel(writer, index=False)
        # Also update the in-memory reference so download endpoint works mid-job
        bulk_jobs[job_id]['results_df'] = partial_df
    except Exception as e:
        print(f"Warning: Could not save partial results: {e}")

@app.route('/api/bulk-process', methods=['POST'])
def bulk_process():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Empty filename"}), 400

    li_at = os.getenv("LI_AT")
    if not li_at:
        return jsonify({"error": "LinkedIn session cookie missing on server"}), 500

    try:
        if file.filename.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)
            
        job_id = str(uuid.uuid4())
        bulk_jobs[job_id] = {
            'status': 'processing',
            'progress': 0,
            'results_df': None
        }
        
        extract_only = request.form.get('extract_only') == 'true'

        # Start background task
        thread = threading.Thread(target=run_bulk_analysis, args=(job_id, df, li_at, extract_only))
        thread.start()
        
        return jsonify({"job_id": job_id})
        
    except Exception as e:
        return jsonify({"error": f"Failed to parse file: {str(e)}"}), 500

@app.route('/api/bulk-website-extract', methods=['POST'])
def bulk_website_extract():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Empty filename"}), 400

    try:
        if file.filename.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)
        
        # Apply row range if provided (1-indexed from user)
        start_row = request.form.get('start_row')
        end_row = request.form.get('end_row')
        
        if start_row:
            start_idx = max(0, int(start_row) - 1)  # Convert to 0-indexed
            df = df.iloc[start_idx:]
        if end_row:
            end_idx = int(end_row)
            if start_row:
                end_idx = end_idx - int(start_row) + 1
            df = df.iloc[:end_idx]
        
        df = df.reset_index(drop=True)
            
        job_id = str(uuid.uuid4())
        bulk_jobs[job_id] = {
            'status': 'processing',
            'progress': 0,
            'results_df': None
        }
        
        # Start background task
        thread = threading.Thread(target=run_bulk_website_job, args=(job_id, df))
        thread.start()
        
        return jsonify({"job_id": job_id})
        
    except Exception as e:
        return jsonify({"error": f"Failed to parse file: {str(e)}"}), 500

@app.route('/api/bulk-status/<job_id>')
def bulk_status(job_id):
    job = bulk_jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
        
    return jsonify({
        "status": job['status'],
        "progress": job['progress'],
        "error": job.get('error')
    })

@app.route('/api/bulk-stop/<job_id>', methods=['POST'])
def bulk_stop(job_id):
    job = bulk_jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
        
    job['stop_requested'] = True
    return jsonify({"success": True})

@app.route('/api/bulk-download/<job_id>')
def bulk_download(job_id):
    job = bulk_jobs.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    
    df = job.get('results_df')
    if df is None or len(df) == 0:
        return jsonify({"error": "No results available yet"}), 404
        
    output = io.BytesIO()
    
    # Export to Excel by default for better compatibility
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False)
        
    output.seek(0)
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'analyzed_leads_{job_id[:8]}.xlsx'
    )

# ΓöÇΓöÇ First Name Extraction ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

def run_name_extraction_job(job_id, df, li_at):
    try:
        results = []
        total = len(df)
        
        # Find the LinkedIn URL column
        li_col = next((c for c in df.columns if 'linkedin' in c.lower()), None)
        if not li_col:
            li_col = next((c for c in df.columns if 'url' in c.lower()), None)
        if not li_col:
            li_col = df.columns[0]
        
        log(f"[Name Extract] Job {job_id[:8]}: Using column '{li_col}' ({total} rows)")
        
        output_path = os.path.join(os.path.dirname(__file__) or '.', f'names_{job_id[:8]}.xlsx')
        
        for row_num, (index, row) in enumerate(df.iterrows()):
            url = str(row[li_col]).strip()
            progress = int(((row_num + 1) / total) * 100)
            bulk_jobs[job_id]['progress'] = progress
            
            log(f"[Name Extract] Row {row_num + 1}/{total} ({progress}%): {url}")
            
            if not url or 'linkedin.com' not in url or url.lower() == 'nan':
                results.append({**row.to_dict(), "full_name": "", "error": "Invalid LinkedIn URL"})
                _save_partial_results(results, output_path, job_id)
                continue
            
            try:
                # Small delay to avoid rate limiting (much shorter since no browser scraping)
                if row_num > 0:
                    delay = random.uniform(2, 5)
                    log(f"[Name Extract] Waiting {delay:.1f}s...")
                    time.sleep(delay)
                
                full_name = _extract_name_from_linkedin(url)
                
                if full_name:
                    log(f"[Name Extract] Found: {full_name}")
                    results.append({**row.to_dict(), "full_name": full_name})
                else:
                    results.append({**row.to_dict(), "full_name": "", "error": "Could not extract name"})
                
            except Exception as e:
                print(f"Error processing row {row_num}: {e}")
                results.append({**row.to_dict(), "full_name": "", "error": str(e)})
            
            _save_partial_results(results, output_path, job_id)
        
        # Finalize
        output_df = pd.DataFrame(results)
        bulk_jobs[job_id]['results_df'] = output_df
        bulk_jobs[job_id]['progress'] = 100
        bulk_jobs[job_id]['status'] = 'completed'
        log(f"[Name Extract] Job {job_id[:8]} completed. {total} names extracted.")
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        log(f"[Name Extract] FATAL ERROR in job {job_id[:8]}: {e}")
        bulk_jobs[job_id]['status'] = 'error'
        bulk_jobs[job_id]['error'] = str(e)

@app.route('/api/bulk-name-extract', methods=['POST'])
def bulk_name_extract():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "Empty filename"}), 400

    li_at = os.getenv("LI_AT")
    if not li_at:
        return jsonify({"error": "LinkedIn session cookie missing on server"}), 500

    try:
        if file.filename.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)
            
        job_id = str(uuid.uuid4())
        bulk_jobs[job_id] = {
            'status': 'processing',
            'progress': 0,
            'results_df': None
        }
        
        thread = threading.Thread(target=run_name_extraction_job, args=(job_id, df, li_at))
        thread.start()
        
        return jsonify({"job_id": job_id})
        
    except Exception as e:
        return jsonify({"error": f"Failed to parse file: {str(e)}"}), 500

# ΓöÇΓöÇ Personalize API ΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇΓöÇ

@app.route('/api/personalize', methods=['POST'])
def personalize():
    data = request.json
    website = data.get('website')

    if not website:
        return jsonify({"error": "website field is required"}), 400

    print(f"Received personalize request for: {website}")

    try:
        scraped = scrape_website_rich(website, headless=True)
        if not scraped:
            return jsonify({"error": "Failed to scrape website."}), 500

        site_data = extract_website_data(
            scraped.get('visible_text', ''),
            structural_signals=scraped.get('structural_signals')
        )
        if not site_data:
            return jsonify({"error": "Failed to extract insights from website text."}), 500

        return jsonify(site_data)

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(tb)
        return jsonify({"error": f"Server Error: {str(e)}", "traceback": tb}), 500


@app.route('/api/name-extract', methods=['POST', 'OPTIONS'], strict_slashes=False)
def name_extract_single():
    """
    Extract the full name from a single LinkedIn profile URL — FREE, no login needed.
    Layer 1: HTTP GET → parse <title> tag
    Layer 2: Google search fallback
    Body (JSON): { "url": "https://linkedin.com/in/..." }
    Returns:     { "full_name": "John Smith", "url": "..." }
    """
    data = request.json
    url = (data or {}).get('url', '').strip()

    if not url:
        return jsonify({"error": "url is required"}), 400

    if 'linkedin.com' not in url:
        return jsonify({"error": "URL must be a LinkedIn profile link"}), 400

    try:
        log(f"[Name Extract] Request for: {url}")
        full_name = _extract_name_from_linkedin(url)

        if full_name:
            log(f"[Name Extract] Result: {full_name}")
            return jsonify({"full_name": full_name, "url": url})
        else:
            return jsonify({"error": "Could not extract name from this profile", "url": url}), 404

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


def _extract_name_from_linkedin(url: str) -> str | None:
    """
    Try to get the full name from a LinkedIn URL without login.
    Layer 1: HTTP request to LinkedIn → parse <title>
    Layer 2: Google SERP fallback
    Layer 3: URL slug parsing
    """
    import requests
    import re

    # ── Layer 1: Direct HTTP GET to LinkedIn ──
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Referer": "https://www.google.com/",
        }
        resp = requests.get(url, headers=headers, timeout=15, allow_redirects=True)
        
        if resp.status_code == 200:
            # LinkedIn <title> is always: "FirstName LastName - Title | LinkedIn"
            title_match = re.search(r'<title[^>]*>([^<]+)</title>', resp.text, re.IGNORECASE)
            if title_match:
                title = title_match.group(1).strip()
                # Parse "John Smith - CEO at Company | LinkedIn"
                name = title.split(' - ')[0].split(' | ')[0].strip()
                # Validate: skip if it's a generic LinkedIn page title
                if name and name.lower() not in ('linkedin', 'linkedin login', 'sign in', ''):
                    log(f"[Name Extract] Got from title tag: {name}")
                    return name
        else:
            log(f"[Name Extract] LinkedIn returned status {resp.status_code}, trying Google...")
    except Exception as e:
        log(f"[Name Extract] Direct request failed: {e}, trying Google...")

    # ── Layer 2: Google search fallback ──
    try:
        from playwright.sync_api import sync_playwright
        
        search_query = f'site:linkedin.com "{url.split("/in/")[-1].split("?")[0].rstrip("/")}"'
        
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-dev-shm-usage"])
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
                viewport={"width": 1280, "height": 800},
            )
            page = context.new_page()
            
            try:
                page.goto(f"https://www.google.com/search?q={search_query}", timeout=15000)
                page.wait_for_selector("#search", timeout=5000)
                
                # Google shows: "FirstName LastName - Title - LinkedIn"
                first_result = page.locator("#search h3").first
                if first_result.count() > 0:
                    result_text = first_result.inner_text().strip()
                    name = result_text.split(' - ')[0].split(' | ')[0].strip()
                    if name and name.lower() not in ('linkedin', ''):
                        log(f"[Name Extract] Got from Google: {name}")
                        return name
            except Exception:
                pass
            finally:
                browser.close()
    except Exception as e:
        log(f"[Name Extract] Google fallback failed: {e}")

    # ── Layer 3: URL slug parsing (last resort) ──
    try:
        slug = url.split('/in/')[-1].split('?')[0].rstrip('/')
        # Remove trailing numbers/IDs like "john-smith-12345"
        parts = slug.split('-')
        # Strip parts that are all digits or very long hex
        name_parts = []
        for part in parts:
            if part.isdigit() or (len(part) > 6 and all(c in '0123456789abcdef' for c in part)):
                break
            name_parts.append(part.capitalize())
        
        if name_parts:
            name = ' '.join(name_parts)
            log(f"[Name Extract] Got from URL slug: {name}")
            return name
    except Exception:
        pass

    return None


# ── Lead Discovery ─────────────────────────────────────────────────────────

# In-memory store for discovery jobs
discovery_jobs = {}
_discovery_lock = threading.Lock()  # Prevent concurrent discovery jobs

# Job cleanup: expire completed jobs older than 1 hour
def _cleanup_stale_jobs():
    """Remove completed/errored jobs older than 1 hour to prevent memory leaks."""
    import time as _time
    now = _time.time()
    stale = []
    for jid, job in list(discovery_jobs.items()):
        if job.get('status') in ('completed', 'stopped', 'error'):
            if now - job.get('completed_at', now) > 3600:
                stale.append(jid)
    for jid in stale:
        del discovery_jobs[jid]
    # Also clean bulk_jobs
    for jid, job in list(bulk_jobs.items()):
        if job.get('status') in ('completed', 'error'):
            if now - job.get('completed_at', now) > 3600:
                del bulk_jobs[jid]


def run_lead_discovery_job(job_id: str, config: dict, stop_event: threading.Event):
    """Background worker: Google Custom Search API -> save leads."""
    try:
        from dork_engine import run as dork_run

        discovery_jobs[job_id]['status'] = 'searching'
        discovery_jobs[job_id]['message'] = 'Searching for LinkedIn profiles via Serper...'
        discovery_jobs[job_id]['found_count'] = 0
        log(f"[Discovery] Job {job_id[:8]}: starting Serper search...")

        def progress_cb(found, total_q, current_q, query):
            discovery_jobs[job_id]['found_count'] = found
            discovery_jobs[job_id]['progress'] = int((current_q / total_q) * 100)
            discovery_jobs[job_id]['message'] = (
                f'Query {current_q}/{total_q} -- {found} leads found so far'
            )

        discovered_urls = dork_run(
            config=config,
            stop_event=stop_event,
            progress_callback=progress_cb
        )

        if stop_event.is_set():
            discovery_jobs[job_id]['status'] = 'stopped'
            discovery_jobs[job_id]['message'] = f'Stopped by user. Saving {len(discovered_urls)} discovered URLs...'

        # Save to persistent leads file (deduplication happens inside)
        save_result = save_new_leads(discovered_urls)

        import time as _time
        discovery_jobs[job_id]['status'] = 'completed'
        discovery_jobs[job_id]['progress'] = 100
        discovery_jobs[job_id]['found_count'] = save_result['added']
        discovery_jobs[job_id]['message'] = (
            f"{save_result['added']} new leads saved | "
            f"{save_result['duplicates']} duplicates skipped | "
            f"{save_result['total']} total in file"
        )
        discovery_jobs[job_id]['save_result'] = save_result
        discovery_jobs[job_id]['completed_at'] = _time.time()
        log(f"[Discovery] Job {job_id[:8]} complete: {save_result}")

    except Exception as e:
        import traceback
        traceback.print_exc()
        log(f"[Discovery] Job {job_id[:8]} FATAL ERROR: {e}")
        discovery_jobs[job_id]['status'] = 'error'
        discovery_jobs[job_id]['message'] = str(e)


@app.route('/api/find-leads', methods=['POST'])
def find_leads():
    """Start a lead discovery job. Only one can run at a time."""
    import json as _json

    # Prevent concurrent discovery jobs
    with _discovery_lock:
        active = [j for j in discovery_jobs.values()
                  if j.get('status') in ('starting', 'searching')]
        if active:
            return jsonify({'error': 'A discovery job is already running. Stop it first or wait for it to finish.'}), 409

    # Clean up stale jobs
    _cleanup_stale_jobs()

    try:
        with open(os.path.join(os.path.dirname(__file__), 'dorks_config.json')) as f:
            config = _json.load(f)

        # Allow optional overrides from request body with bounds checking
        body = request.get_json(silent=True) or {}
        if 'max_urls_target' in body:
            config['max_urls_target'] = max(10, min(int(body['max_urls_target']), 2000))
        if 'max_pages_per_dork' in body:
            config['max_pages_per_dork'] = max(1, min(int(body['max_pages_per_dork']), 5))

        job_id = str(uuid.uuid4())
        stop_event = threading.Event()
        discovery_jobs[job_id] = {
            'status': 'starting',
            'progress': 0,
            'found_count': 0,
            'message': 'Initialising...',
            'stop_event': stop_event
        }

        t = threading.Thread(
            target=run_lead_discovery_job,
            args=(job_id, config, stop_event),
            daemon=True
        )
        t.start()

        return jsonify({'job_id': job_id})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/find-leads-status/<job_id>')
def find_leads_status(job_id):
    job = discovery_jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    return jsonify({
        'status': job['status'],
        'progress': job.get('progress', 0),
        'found_count': job.get('found_count', 0),
        'message': job.get('message', ''),
        'save_result': job.get('save_result')
    })


@app.route('/api/find-leads-stop/<job_id>', methods=['POST'])
def find_leads_stop(job_id):
    job = discovery_jobs.get(job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404
    job['stop_event'].set()
    return jsonify({'success': True})


@app.route('/api/leads', methods=['GET'])
def get_leads():
    """Return all saved leads + count."""
    leads = get_all_leads()
    return jsonify({'leads': leads, 'count': len(leads)})


@app.route('/api/leads/clear', methods=['POST'])
def clear_leads():
    count = clear_all_leads()
    return jsonify({'cleared': count})


@app.route('/api/leads/delete', methods=['POST'])
def delete_single_lead():
    data = request.get_json(silent=True) or {}
    url = data.get('url', '').strip()
    if not url:
        return jsonify({'error': 'url is required'}), 400
    success = delete_lead(url)
    return jsonify({'deleted': success})


@app.route('/api/leads/process', methods=['POST'])
def process_leads():
    """
    Start a bulk processing job using all leads currently saved in discovered_leads.txt.
    Reuses the existing run_bulk_analysis infrastructure.
    """
    li_at = os.getenv('LI_AT')
    if not li_at:
        return jsonify({'error': 'LinkedIn session cookie (LI_AT) missing on server'}), 500

    leads = get_all_leads()
    if not leads:
        return jsonify({'error': 'No leads found in file. Run Lead Discovery first.'}), 400

    # Apply optional row range
    body = request.get_json(silent=True) or {}
    start_row = body.get('start_row')
    end_row = body.get('end_row')

    if start_row is not None:
        leads = leads[int(start_row) - 1:]
    if end_row is not None:
        end_idx = int(end_row) - (int(start_row) - 1 if start_row else 0)
        leads = leads[:end_idx]

    df = pd.DataFrame({'linkedin_url': leads})

    job_id = str(uuid.uuid4())
    bulk_jobs[job_id] = {
        'status': 'processing',
        'progress': 0,
        'results_df': None
    }

    extract_only = body.get('extract_only', False)
    t = threading.Thread(
        target=run_bulk_analysis,
        args=(job_id, df, li_at, extract_only),
        daemon=True
    )
    t.start()

    return jsonify({'job_id': job_id, 'total_leads': len(leads)})


if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    print(f"Starting Flask server on http://0.0.0.0:{port}")
    app.run(host="0.0.0.0", debug=True, use_reloader=False, port=port)

